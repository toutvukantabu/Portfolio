export interface HeroModel {
    id: number;
    title: string;
    name: string;
    lastname: string;
    description: string;
    callToAction: string;
}
