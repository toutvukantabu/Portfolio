import { LucideIcon } from "lucide-react";
export interface SkillModel {
    id: number;
    icon: LucideIcon;
    title: string;
    desc: string;
}
