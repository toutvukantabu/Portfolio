import { ContactFormData } from "@/domain/model/contactFormData/ContactFormData";
export declare const SubmitContactForm: (data: ContactFormData) => Promise<void>;
