export declare const useNavigationLinks: () => {
    links: {
        id: string;
        label: string;
    }[];
    pages: {
        path: string;
        label: string;
    }[];
};
