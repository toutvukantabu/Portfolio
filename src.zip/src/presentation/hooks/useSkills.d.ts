import { SkillModel } from "@/domain/model/skill/SkillModel";
/**
 * 🧩 useSkills
 *
 * ▶️ Rôle :
 * Hook React pour charger les compétences.
 *
 * ▶️ Fonctionnement :
 * Récupère le UseCase via Context, exécute le chargement, et retourne les Skills.
 */
export declare const useSkills: () => {
    skills: SkillModel[];
};
