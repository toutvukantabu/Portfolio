export declare const useSmoothScroll: () => {
    scrollToSection: (id: string) => void;
};
