export declare const useLanguageSwitcher: () => {
    currentLanguage: string;
    changeLanguage: (lang: string) => void;
    isFading: boolean;
};
