import { ExperienceModel } from "@/domain/model/experience/ExperienceModel";
export declare const useExperiences: () => ExperienceModel[];
