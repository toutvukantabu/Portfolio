import { SubmitHandler } from "react-hook-form";
import { ContactFormData } from "@/domain/model/contactFormData/ContactFormData";
export declare const useContactForm: () => {
    t: import("i18next").TFunction<"translation", undefined>;
    register: import("react-hook-form").UseFormRegister<ContactFormData>;
    handleSubmit: import("react-hook-form").UseFormHandleSubmit<ContactFormData, undefined>;
    errors: import("react-hook-form").FieldErrors<ContactFormData>;
    isLoading: boolean;
    onSubmit: SubmitHandler<ContactFormData>;
};
