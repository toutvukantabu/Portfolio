import { HeroModel } from "@/domain/model/hero/HeroModel";
export declare const useHeroContent: () => HeroModel | null;
