export declare const useNavbar: () => {
    scrolled: boolean;
    isMenuOpen: boolean;
    toggleMenu: () => void;
};
