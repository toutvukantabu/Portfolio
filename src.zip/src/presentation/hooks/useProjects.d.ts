import { ProjectModel } from "@/domain/model/project/ProjectModel";
export declare const useProjects: () => ProjectModel[];
