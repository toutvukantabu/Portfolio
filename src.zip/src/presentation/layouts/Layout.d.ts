import React from "react";
declare const Layout: React.FC;
export default Layout;
