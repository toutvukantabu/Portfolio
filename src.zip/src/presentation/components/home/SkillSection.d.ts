import React from "react";
/**
 * 🖥️ SkillSection
 *
 * ▶️ Rôle :
 * Composant UI qui affiche la liste des compétences.
 *
 * ▶️ Fonctionnement :
 * Utilise le hook useSkills pour récupérer les données et les rend avec des icônes.
 */
declare const SkillsSection: React.FC;
export default SkillsSection;
