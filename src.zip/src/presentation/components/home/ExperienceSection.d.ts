import React from "react";
declare const ExperienceSection: React.FC;
export default ExperienceSection;
