import React from "react";
declare const CollaborateSection: React.FC;
export default CollaborateSection;
