import React from "react";
declare const HeroSection: React.FC;
export default HeroSection;
