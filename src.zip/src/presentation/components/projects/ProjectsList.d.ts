import React from "react";
declare const ProjectsPage: React.FC;
export default ProjectsPage;
