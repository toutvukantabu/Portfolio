import React from "react";
declare const ProjectDetailPage: React.FC;
export default ProjectDetailPage;
