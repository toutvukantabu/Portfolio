import React from "react";
declare const ContactSection: React.FC;
export default ContactSection;
