import React from "react";
declare const ContactForm: React.FC;
export default ContactForm;
