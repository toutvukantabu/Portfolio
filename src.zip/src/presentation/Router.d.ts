export default function Router(): import("react/jsx-runtime").JSX.Element;
