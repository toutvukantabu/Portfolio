import { jsx as _jsx } from "react/jsx-runtime";
import { SkillsContext } from "@/application/context/skill/skillsContext";
export const SkillsProvider = ({ useCase, children }) => {
    return (_jsx(SkillsContext.Provider, { value: useCase, children: children }));
};
