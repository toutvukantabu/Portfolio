export declare const LanguageFadeContext: import("react").Context<{
    isFading: boolean;
}>;
export declare const useLanguageFade: () => {
    isFading: boolean;
};
