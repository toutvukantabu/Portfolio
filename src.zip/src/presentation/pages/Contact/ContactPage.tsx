import React from "react";
import ContactSection from "@/presentation/components/contact/ContactSection";

const ContactPage: React.FC = () => {


    return (
            <ContactSection/>
    );
};

export default ContactPage;
