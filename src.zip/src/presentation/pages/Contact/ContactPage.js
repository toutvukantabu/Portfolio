import { jsx as _jsx } from "react/jsx-runtime";
import ContactSection from "@/presentation/components/contact/ContactSection";
const ContactPage = () => {
    return (_jsx(ContactSection, {}));
};
export default ContactPage;
