import React from "react";
declare const ContactPage: React.FC;
export default ContactPage;
