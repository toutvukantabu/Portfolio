declare const Home: () => import("react/jsx-runtime").JSX.Element;
export default Home;
