import { jsx as _jsx } from "react/jsx-runtime";
import ProjectItem from "@/presentation/components/projects/ProjectItem";
const ProjectPage = () => {
    return (_jsx(ProjectItem, {}));
};
export default ProjectPage;
