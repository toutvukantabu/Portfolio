import { jsx as _jsx } from "react/jsx-runtime";
import ProjectsList from "@/presentation/components/projects/ProjectsList";
const ProjectsPage = () => {
    return (_jsx(ProjectsList, {}));
};
export default ProjectsPage;
