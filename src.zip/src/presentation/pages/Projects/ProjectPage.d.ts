import React from "react";
declare const ProjectPage: React.FC;
export default ProjectPage;
