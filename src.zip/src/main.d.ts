import './index.css';
import '@/core/i18n/i18n';
