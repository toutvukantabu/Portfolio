declare const useIntersectionObserver: (animationClass: string, targetClass: string, dependencies?: any[]) => void;
export default useIntersectionObserver;
