export declare const useLocale: () => "en" | "fr";
