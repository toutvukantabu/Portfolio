export declare const BackgroundLines: () => import("react/jsx-runtime").JSX.Element;
