import React from "react";
declare const Footer: React.FC;
export default Footer;
