import React from "react";
declare const LanguageSwitcher: React.FC;
export default LanguageSwitcher;
