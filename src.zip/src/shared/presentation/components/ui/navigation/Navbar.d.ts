import React from "react";
declare const Navbar: React.FC;
export default Navbar;
