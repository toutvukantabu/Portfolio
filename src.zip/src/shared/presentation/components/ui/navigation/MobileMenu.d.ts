import React from "react";
interface MobileMenuProps {
    isOpen: boolean;
    toggleMenu: () => void;
    links: {
        id: string;
        label: string;
    }[];
    pages: {
        path: string;
        label: string;
    }[];
}
declare const MobileMenu: React.FC<MobileMenuProps>;
export default MobileMenu;
