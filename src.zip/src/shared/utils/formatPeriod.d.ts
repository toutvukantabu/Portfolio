export declare const formatPeriod: (startDate: string, endDate?: string, locale?: string) => string;
