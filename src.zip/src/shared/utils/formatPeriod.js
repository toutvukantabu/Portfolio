export const formatPeriod = (startDate, endDate, locale = "fr") => {
    const options = { year: "numeric", month: "long" };
    const formattedStart = new Date(startDate).toLocaleDateString(locale, options);
    const formattedEnd = endDate
        ? new Date(endDate).toLocaleDateString(locale, options)
        : locale === "en" ? "Present" : "Aujourd'hui";
    return `${formattedStart} – ${formattedEnd}`;
};
