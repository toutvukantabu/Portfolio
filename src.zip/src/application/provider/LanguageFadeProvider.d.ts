import React from "react";
export declare const LanguageFadeProvider: React.FC<{
    children: React.ReactNode;
}>;
