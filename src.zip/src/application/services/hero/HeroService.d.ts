import { HeroModel } from "@/domain/model/hero/HeroModel";
export declare class HeroService {
    static getHero(locale: string): Promise<HeroModel | null>;
}
