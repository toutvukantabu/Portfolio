import { SkillModel } from "@/domain/model/skill/SkillModel";
export declare class SkillService {
    static getSkills(locale: string): Promise<SkillModel[]>;
}
