export class GetExperiencesUseCase {
    constructor(repository) {
        Object.defineProperty(this, "repository", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: repository
        });
    }
    async execute(locale) {
        const experiences = await this.repository.getAll(locale);
        return experiences.sort((a, b) => {
            if (!a.endDate && b.endDate)
                return -1;
            if (a.endDate && !b.endDate)
                return 1;
            return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
        });
    }
}
