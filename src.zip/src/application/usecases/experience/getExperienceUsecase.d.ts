import { ExperienceModel } from "@/domain/model/experience/ExperienceModel";
import { StrapiExperienceRepository } from "@/infrastructure/repositories/experience/StrapiExperienceRepository";
export declare class GetExperiencesUseCase {
    private repository;
    constructor(repository: StrapiExperienceRepository);
    execute(locale: string): Promise<ExperienceModel[]>;
}
