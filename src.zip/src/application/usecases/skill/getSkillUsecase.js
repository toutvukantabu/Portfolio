export class GetSkillsUseCase {
    constructor(repository) {
        Object.defineProperty(this, "repository", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: repository
        });
    }
    async execute(locale) {
        const all = await this.repository.getAll(locale);
        return all.filter(skill => skill.title.trim() !== "");
    }
}
