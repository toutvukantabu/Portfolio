import { createContext } from "react";
/**
 * ⚡ SkillsContext
 *
 * ▶️ Rôle :
 * Crée un contexte React pour injecter le GetSkillsUseCase.
 *
 * ▶️ Fonctionnement :
 * Permet aux composants enfants d'accéder au use case sans passer par des props.
 */
export const SkillsContext = createContext(null);
