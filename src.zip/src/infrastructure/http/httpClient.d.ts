export declare const httpClient: import("axios").AxiosInstance;
export declare const safeGet: (url: string, config?: {}) => Promise<any>;
