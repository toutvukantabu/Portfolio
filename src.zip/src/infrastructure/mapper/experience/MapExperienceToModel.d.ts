import { ExperienceModel } from "@/domain/model/experience/ExperienceModel";
export declare const MapExperienceToModel: (item: any) => ExperienceModel;
