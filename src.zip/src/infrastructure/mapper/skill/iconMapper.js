import { Cloud, Code2, Cpu, Database, GitBranch, Server, Shield, Terminal, } from "lucide-react";
export const iconMap = {
    database: Database,
    backend: Server,
    api: Code2,
    versioning: GitBranch,
    devops: Terminal,
    infrastructure: Cloud,
    automation: Cpu,
    security: Shield,
};
