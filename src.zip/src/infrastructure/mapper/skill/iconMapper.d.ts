export declare const iconMap: Record<string, any>;
