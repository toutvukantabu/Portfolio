import { SkillModel } from "@/domain/model/skill/SkillModel";
export declare const mapStrapiSkillToModel: (item: any) => SkillModel;
