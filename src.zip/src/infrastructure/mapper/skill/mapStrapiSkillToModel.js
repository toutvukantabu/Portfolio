import { iconMap } from "./iconMapper";
export const mapStrapiSkillToModel = (item) => {
    const skill = item.skill;
    return {
        id: item.id,
        title: skill.title,
        desc: skill.desc,
        icon: iconMap[skill.icon] ?? iconMap["default"],
    };
};
