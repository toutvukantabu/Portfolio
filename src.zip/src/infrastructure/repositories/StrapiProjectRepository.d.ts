import { ProjectModel } from "@/domain/model/project/ProjectModel";
export declare class StrapiProjectRepository {
    static getProjects(): ProjectModel[];
}
