import { ExperienceModel } from "@/domain/model/experience/ExperienceModel";
export declare class StrapiExperienceRepository {
    getAll(locale: string): Promise<ExperienceModel[]>;
}
