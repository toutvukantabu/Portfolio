import { httpClient } from "@/infrastructure/http/httpClient";
import { MapExperienceToModel } from "@/infrastructure/mapper/experience/MapExperienceToModel";
export class StrapiExperienceRepository {
    async getAll(locale) {
        const response = await httpClient.get("/experiences", {
            params: { populate: "*", locale },
        });
        return response.data.data.map(MapExperienceToModel);
    }
}
