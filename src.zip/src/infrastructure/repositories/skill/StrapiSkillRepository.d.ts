import { SkillModel } from "@/domain/model/skill/SkillModel";
import { SkillRepository } from "@/domain/model/skill/SkillRepository";
export declare class StrapiSkillRepository implements SkillRepository {
    getAll(locale: string): Promise<SkillModel[]>;
}
