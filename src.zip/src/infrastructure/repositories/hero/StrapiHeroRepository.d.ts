import { HeroRepository } from "@/domain/model/hero/HeroRepository";
import { HeroModel } from "@/domain/model/hero/HeroModel";
export declare class StrapiHeroRepository implements HeroRepository {
    getContent(locale: string): Promise<HeroModel>;
}
