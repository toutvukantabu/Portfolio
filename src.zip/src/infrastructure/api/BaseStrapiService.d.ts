export declare class BaseStrapiService<T> {
    private endpoint;
    constructor(endpoint: string);
    /**
     * Récupère un seul élément (le premier de la liste)
     */
    getOne(locale: string): Promise<T | null>;
    /**
     * Récupère tous les éléments de la collection
     */
    getAll(locale: string): Promise<T[]>;
}
